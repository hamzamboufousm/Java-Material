package edu.uob;

public class Fruit extends Food {

  //TODO:

}
