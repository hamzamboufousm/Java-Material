package edu.uob;

public class Chocolate extends Food {

  //TODO:

}
