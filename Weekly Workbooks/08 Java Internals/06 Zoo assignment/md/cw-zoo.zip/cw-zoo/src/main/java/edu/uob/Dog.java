package edu.uob;

public class Dog extends Animal {

  //TODO:

}
