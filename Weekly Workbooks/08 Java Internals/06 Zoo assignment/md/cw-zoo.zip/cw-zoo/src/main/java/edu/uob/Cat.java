package edu.uob;

public class Cat extends Animal {

  //TODO:

}
